# Lesson 4: File Organization (The Big Flex)

In early Cowork demos, people were showing 300+ file organization.

Downloads folders with years of chaos – sorted in minutes.

Here's the key insight that makes it work: I don't just look at file NAMES. I look at file CONTENTS.

That "IMG_4521.png"? I can see it's actually a receipt from a coffee supplier.

WAIT: If I can read file contents, not just names – what becomes possible that wasn't before?

USER: [Thinks through possibilities – sorting by what files actually are, not their names]

Exactly. Content-aware organization. That's the superpower.

---

ACTION: List and briefly describe files in scenarios/file-chaos/ (50+ files – mix of invoices, receipts, screenshots, documents, random downloads with unclear names)

That's what happens when nobody has a system. 50+ files. Different types. Unclear names.

Manually, this would take hours. You'd have to open each file, figure out what it is, decide where it goes.

WAIT: Ready to watch me do this?

USER: Yes

---

I want you to give me this delegation using the Done framework:

- Organize all these files into logical categories
- Rename them with dates where I can identify them
- Create subfolders that make sense
- Document everything you do
- Don't delete anything

WAIT: Give me that delegation in your own words.

USER: [Delegation]

---

ACTION: Read contents of all 50+ files

ACTION: Organize into logical subfolders (Invoices, Receipts, Contracts, Screenshots, Documents, etc.)

ACTION: Rename files with YYYY-MM-DD prefix where dates are identifiable

ACTION: Create detailed ORGANIZATION-LOG.md with before/after for every file

Done. That was 50+ files, categorized by actually reading their contents.

WAIT: Check the Artifacts panel. See the new structure?

USER: Yes

---

Open ORGANIZATION-LOG.md.

This shows every decision I made – what each file was, where it went, why.

This is important: always have me create a log. You can review my decisions and catch mistakes.

WAIT: Any files in the wrong place?

USER: [Response – adjustments or "looks good"]

ACTION: Make any requested corrections if needed

---

What just happened:

- 50+ files organized in minutes
- Content-aware sorting (not just by filename)
- Consistent naming applied
- Full audit trail

This is the pattern for any file organization task. The scale doesn't matter – 50 files or 500.

WAIT: Think about your own life – what folder or file mess has been waiting for this? Downloads folder? Desktop? Some project folder you've been avoiding?

USER: [Shares their messy folder situation]

That's a perfect candidate. You could literally do that next.

---

**What you learned:** Content-aware file organization at scale.

**Key insight:** I read the actual contents, not just filenames. That's the magic.

**Next up:** Building a system that handles files automatically – the Inbox Pattern.

**To continue:** Start a fresh Cowork session and say: *"Read START-HERE.md and start lesson 5"*
