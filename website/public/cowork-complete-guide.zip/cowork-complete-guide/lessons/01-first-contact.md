# Lesson 1: First Contact

Welcome to the Cowork Complete Guide.

I'm going to teach you to use Claude Cowork – not by explaining features, but by doing real work together. By the end, you'll have a system for file organization, research, and document creation that you can use forever.

WAIT: Ready to start?

USER: Yes

---

Here's the thing most people get wrong: they treat Cowork like ChatGPT with folder access.

Ask a question, get an answer, copy-paste the output somewhere.

That's not what this is.

Cowork is a **worker**. You describe an outcome and step away. It plans, executes, organizes files, creates spreadsheets with real formulas, drafts reports – all while you do something else.

WAIT: Does that make sense? Worker, not chatbot?

USER: Yes

---

Think of it this way:

- **Regular Claude** = a researcher who answers questions
- **Claude Code** = a CTO who writes code
- **Cowork** = a COO who operates your work life

File organization, research synthesis, document creation, data analysis – the operational stuff.

As Anthropic puts it: "It feels much less like a back-and-forth and much more like leaving messages for a coworker."

WAIT: That mental shift is everything. Ready to see it in action?

USER: Yes

---

Look at your screen. You've got:

- This chat on the left – where we communicate
- The Artifacts panel on the right – where files I create or touch appear

Important: you can only see files I've interacted with. You can't browse the whole folder from here.

Let me show you.

ACTION: Create a simple text file called "hello.txt" with the content "Welcome to the Cowork Complete Guide! This file was created by Claude."

See how that appeared in your Artifacts panel? Click on it.

WAIT: Can you see the hello.txt file on the right?

USER: Yes

---

A few things to know about Cowork:

The Claude Desktop app must stay open while tasks run. If you close it or your computer sleeps, the session ends.

There's no memory across sessions. Each time you start fresh.

But files persist – anything I create stays in your folder. That's how your skills and outputs survive.

WAIT: What do you think would happen if you closed the app mid-task?

USER: [Explains that the session would end / work would stop]

Exactly. Keep it open while I'm working. You can minimize it, but don't close it.

---

One quirk: Cowork doesn't automatically read instruction files.

That's why you had to say "Read START-HERE.md and follow those instructions" to begin.

For this course, you'll do that at the start of each session. In your own work, you can create similar instruction files – they're called Skills.

WAIT: Ready to do your first real task?

USER: Yes

---

**What you learned:** Cowork is a worker, not a chatbot. Delegate outcomes, step away, come back to finished work.

**Next up:** You're going to give me your first real delegation and see the difference between asking and telling.

**To continue:** Start a fresh Cowork session and say: *"Read START-HERE.md and start lesson 2"*
