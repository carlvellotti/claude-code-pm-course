# Lesson 6: Research Synthesis

You've got 20 customer feedback documents.

Surveys. Emails. Interview notes. Support tickets.

You need to find the patterns.

Manually, you'd read every document, take notes, look for themes, cross-reference, write up findings.

Hours of work.

WAIT: Ever had to do this manually?

USER: Yes / Sounds painful

---

I'm going to read all 20 documents and synthesize them.

Not summarize each one – *synthesize* across all of them.

Find themes. Spot contradictions. Connect dots you'd miss.

WAIT: What's your prediction – will the feedback mostly agree or contradict each other?

USER: [Makes a prediction]

Let's find out.

---

ACTION: List the 20 documents in scenarios/customer-feedback/ with brief descriptions

That's a lot of reading. Different formats, lengths, perspectives.

Here's the key: tell me what questions you're trying to answer.

Don't just say "summarize these." Tell me what insights you need.

WAIT: What do you want to learn from this customer feedback?

USER: [Specific questions]

---

ACTION: Read all 20 documents thoroughly

ACTION: Create synthesis report with:
- Executive summary
- Key themes (with supporting quotes and source files cited)
- Contradictions between sources
- Patterns by customer segment (if identifiable)
- Specific feature requests mentioned
- Recommended actions
- Questions that remain unanswered

Done. Here's your synthesis.

WAIT: Take a look. Does this answer your questions?

USER: [Response]

---

Notice something important: I connected dots ACROSS documents.

Customer A said one thing. Customer B said something related. Customer C contradicted both.

That cross-referencing is almost impossible to do manually. Your brain can't hold 20 documents at once.

I cited sources so you can verify anything that seems off.

WAIT: See any insights you wouldn't have found yourself?

USER: [Response]

---

This pattern works for:

- Customer feedback (like we just did)
- Competitive research
- Literature reviews
- Meeting notes across multiple meetings
- Interview transcripts
- Any time you have multiple sources about the same topic

WAIT: Ready to go bigger?

USER: Yes

---

**What you learned:** Multi-document synthesis with source attribution.

**Key insight:** Cross-source analysis at scale. I hold all documents in context simultaneously.

**Next up:** Research at scale – sub-agents and web search.

**To continue:** Start a fresh Cowork session and say: *"Read START-HERE.md and start lesson 7"*
