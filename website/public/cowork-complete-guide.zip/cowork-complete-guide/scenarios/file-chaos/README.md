# File Chaos Scenario

**Used in:** Lesson 4 - File Organization (The Big Flex)

## Purpose
The "big demo" - 50+ messy files that showcase content-aware organization at scale.

## Files Needed (50+ files)
Simulate a neglected Downloads folder:
- Invoices (PDF) - 10+
- Receipts (images, PDFs) - 10+
- Screenshots - 5+
- Documents (contracts, letters, notes) - 10+
- Spreadsheets - 5+
- Random downloads - 10+

Key requirements:
- Many files should have unhelpful names (IMG_xxxx, Document1, download(1), etc.)
- Content should be clearly identifiable when READ (invoices should say "Invoice", etc.)
- Include some duplicates or near-duplicates
- Mix of dates spanning several months
