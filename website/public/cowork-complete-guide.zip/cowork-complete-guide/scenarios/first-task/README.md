# First Task Scenario

**Used in:** Lesson 2 - Your First Delegation

## Purpose
A small set of mixed files for the student's first delegation exercise.

## Files Needed (10 files)
Mix of common file types with unclear names:
- 2-3 PDFs (invoice, receipt, document)
- 2-3 images (screenshot, photo of receipt)
- 1-2 spreadsheets
- 1-2 text/word documents
- 1 random file

Files should have unhelpful names like:
- IMG_4521.png
- Document1.pdf
- download.xlsx
- notes.txt
