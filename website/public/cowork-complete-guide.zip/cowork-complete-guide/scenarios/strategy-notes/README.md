# Strategy Notes Scenario

**Used in:** Lesson 8 - Document Creation (PowerPoint)

## Purpose
Scattered strategy notes for demonstrating presentation creation.

## Files Needed (8-12 documents)
Mix of planning artifacts:
- Brainstorm notes (2-3) - rough ideas, bullet points
- Meeting notes (2-3) - discussion summaries
- Research snippets (2-3) - data points, competitor info
- Draft sections (2-3) - partially written content

Content requirements:
- Should tell a coherent strategy story when synthesized
- Include some data/numbers that could become charts
- Mix of big picture and tactical details
- Some redundancy (same point mentioned in multiple docs)

Good fictional context: "Basecamp Coffee" expansion strategy or new product launch
